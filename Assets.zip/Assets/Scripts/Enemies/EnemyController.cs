using UnityEngine;

public class EnemyController : MonoBehaviour
{
    public Attack[] attackList;

    public Vector3 spawnRoomCenter;

    public GameObject player;

    public void ReceiveAttack()
    {

    }

    public void Move()
    {

    }

    public Vector3 FindTarget()
    {
        return Vector3.zero;
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
