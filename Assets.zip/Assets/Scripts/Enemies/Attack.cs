using UnityEngine;
using System;

public class Attack
{
    public bool isTrigger;

    public float timerSeconds;

    public Action Run;
}
