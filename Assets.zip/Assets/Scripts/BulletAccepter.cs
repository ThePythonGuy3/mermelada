using UnityEngine;

public class BulletAccepter : MonoBehaviour
{
    public virtual void OnHit()
    {

    }
}
